#include <stdio.h>
#include <malloc.h>
#include <stdlib.h>
#include <ctype.h>

typedef struct Node {
    int data;
    char color;
    struct Node * left;
    struct Node * right;
    struct Node * parent;
} Node;

typedef struct Tree {
    Node * root;
    Node * nil;
} Tree;

Tree * newTree(){

    Tree * tree = (Tree*)malloc(sizeof(Tree));
    tree->root = NULL;
    tree->nil = NULL;

    return tree;
}

Node * newNode(Tree * rbt, int value){

    Node * node = (Node*)malloc(sizeof(Node));
    
    if(rbt == NULL){
        node->data = value;
        node->color = 'B';
        node->left = rbt->nil;
        node->right = rbt->nil;
        node->parent = rbt->nil;
        rbt->root = node;
    }
    else{
        node->data = value;
        node->color = 'B';
        node->left = rbt->nil;
        node->right = rbt->nil;
    }

    return node;
}

void insertNode(Tree * rbt, Node * node){

    Node *y, *x = (Node*)malloc(sizeof(Node));
    y = rbt->nil;
    x = rbt->root;

    while(x != rbt->nil){
        y = x;
        if(node->data < x->data)
            x = x->left;
        else
            x = x->right;
    }

    node->parent = y;
    if(y == rbt->nil)
        rbt->root = node;
    else if(node->data < y->data)
        y->left = node;
    else
        y->right = node;
    
    node->left = rbt->nil;
    node->right = rbt->nil;
    //node->color = 'R';

}

void rotateLeft(Tree * rbt, Node * node){
    Node * temp = (Node*)malloc(sizeof(Node));
    temp = node->right;
    node->right = temp->left;
    if (node->right != rbt->nil)
        node->left->parent = node;
    temp->parent = node->parent;
    if (node->parent == rbt->nil)
        rbt->root = temp;
    else if (node == node->parent->left)
        node->parent->left = temp;
    else
        node->parent->right = temp;
    temp->left = node;
    node->parent = temp;

}

void rotateRight(Tree * rbt, Node * node){

    Node * temp = (Node*)malloc(sizeof(Node));
    temp = node->left;
    node->left = temp->right;
    if (node->left != rbt->nil)
        node->right->parent = node;
    temp->parent = node->parent;
    if (node->parent == rbt->nil)
        rbt->root = temp;
    else if (node == node->parent->right)
        node->parent->left = temp;
    else
        node->parent->right = temp;
    temp->right = node;
    node->parent = temp;

}

void fixTree(Tree * rbt, Node * node){

    Node * temp = (Node*)malloc(sizeof(Node));

    while(node->parent->color == 'R'){
        if(node->parent == node->parent->parent->left){
            temp = node->parent->parent->right;
            if(temp->color == 'R'){
                node->parent->color = 'B';
                temp->color = 'B';
                node->parent->parent->color = 'R';
                node = node->parent->parent;
            }
            else{
                node = node->parent;
                rotateLeft(rbt,node);
            }
            node->parent->color = 'B';
            node->parent->parent->color = 'R';
            rotateRight(rbt,node->parent->parent);
        }
        else
            rbt->root->color = 'B';
    }
}

void inorderTraversal(Node * node){

    if(node == NULL)
        return;
    inorderTraversal(node->left);
    printf("%d-%c; ",node->data, node->color);
    inorderTraversal(node->right);
}

int getSecondLargestElement(Tree * rbt, Node * node){
}

int main(void){

    Tree * tree = newTree();
    int nums[8] = {1,8,11,2,7,5,14,15};
    int size = 8;
    int h = 0;
    int bh = 0;
    int secondLargest = nums[0];

    for(int i = 0; i < size; i++){
        Node * node = newNode(tree, nums[i]);
        insertNode(tree, node);
        //fixTree(tree, node);
    }

    inorderTraversal(tree->root);
    printf("\n");
    while(tree->root != tree->nil){
        tree->root = tree->root->right;
        h++;
        bh++;
        if(tree->root->right == tree->nil)
            secondLargest = tree->root->parent->data;
    }
    
    printf("Height: %d\n", h);
    printf("Black height: %d\n", bh);
    printf("Second largest element: %d\n", secondLargest);

    return 0;
}