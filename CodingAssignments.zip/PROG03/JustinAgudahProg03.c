#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

int main()
{
    int f,s,g,u,d;
    int count = 1;
    int passes = 0;
    bool elevator = true;

    printf("Input:\n");
    scanf("%d %d %d %d %d", &f, &s, &g, &u, &d);
    int stops[f];
    stops[0] = s;

    while(elevator){
        if(s==g){
            int i = 1;
            printf("Output:\n");
            printf("%d", stops[0]);
            while(stops[i] < f){
                printf("->%d", stops[i]);
                i++;
            }
            break;
        }
        else if(s >= 1 && s < g && u >= 1 && u <= 100){
            while(s < g){
                s += u;
                stops[count] = s;
                count++;
                if(s > g)
                    passes += 1;
            }
        }
        else if(s >= 1 && s > g && d >= 1 && d <= 100){
            while(s > g){
                s -= d;
                stops[count] = s;
                count++;
                if(s < g)
                    passes += 1;
            }
        }
        else if(passes == 2){
            printf("Use the stairs\n");
            break;
        }
        else{
            printf("Use the stairs\n");
            break;
        }
    }

    return 0;
}