#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <malloc.h>

typedef struct Person {
    char *fName;
    struct Person *next;
    struct Person *firstFriend;
    bool isFriend;
} Person;

typedef struct List {
    Person *head;
} List;

void newPerson(char *name);
void areFriends(Person *person1, Person *person2, char name1, char name2);
void areNotFriends(Person *person1, Person *person2, char name1, char name2);
void printFriends(Person *person, char name);
void friendCheck(Person *person, char name1, char name2);

int main(){
    char choice, *name1, *name2;
    Person *p1, *p2;
    List *list;
    p1 = (Person*)malloc(sizeof(Person));
    p2 = (Person*)malloc(sizeof(Person));
    
    printf("Enter a choice (P, F, U, L, Q, X): ");
    scanf("%c ",&choice);
    while(choice != 'x'){
        switch(choice){
            case 'P':
                newPerson(p1);
                printf("Enter a choice (P, F, U, L, Q, X): ");
                scanf("%c ",&choice);
            
            case 'F':
                scanf("%s %s", &name1, &name2);
                areFriends(p1, p2, name1, name2);
                printf("Enter a choice (P, F, U, L, Q, X): ");
                scanf("%c ",&choice);

            case 'U':
                scanf("%s %s", &name1, &name2);
                areNotFriends(p1, p2, name1, name2);
                printf("Enter a choice (P, F, U, L, Q, X): ");
                scanf("%c ", &choice);

            case 'L':
                scanf("%s", &name1);
                printFriends(p1, name1);
                printf("Enter a choice (P, F, U, L, Q, X): ");
                scanf("%c ", &choice);

            case 'Q':
                scanf("%s %s", &name1, &name2);
                friendCheck(p1, name1, name2);
                printf("Enter a choice (P, F, U, L, Q, X): ");
                scanf("%c ", &choice);

            default:
                printf("Enter a choice (P, F, U, L, Q, X): ");
                scanf("%c ",&choice);
        }
    }

    return 0;
}

void newPerson(char *name){
    scanf("%s", person->name);
    person->next = NULL;
    person->firstFriend = NULL;
    person->isFriend = true;
}

void areFriends(Person *person1, Person *person2, char name1, char name2){
    Person *temp = NULL;
    if(person1->firstFriend == NULL){
        person1->firstFriend = person2;
        person2->isFriend = true;
    }
    else{
        temp = person1->firstFriend;
        while(person1->firstFriend->next != NULL){
            person1->firstFriend = person1->firstFriend->next;
        }
        person1->firstFriend->next = person2;
        person2->isFriend = true;

        person1->firstFriend = temp;
    }

    if(person2->firstFriend == NULL){
        person2->firstFriend = person1;
        person1->isFriend = true;
    }
    else{
        temp = person2->firstFriend;
        while(person2->firstFriend->next != NULL){
            person2->firstFriend = person2->firstFriend->next;
        }
        person2->firstFriend->next = person1;
        person1->isFriend = true;

        person2->firstFriend = temp;
    }
}

void areNotFriends(Person *person1, Person *person2, char name1, char name2){}

void printFriends(Person *person, char name){
    Person *temp = person->firstFriend;

    while(person != NULL){
        if(person->name == name){
            while(person->firstFriend != NULL){
                if(person->firstFriend->isFriend == true)
                    printf("%s ", person->firstFriend->name);
                    person->firstFriend = person->firstFriend->next;
            }
            printf("\n");
        }
    }
    person->firstFriend = temp;
}

void friendCheck(Person *person, char name1, char name2){
    Person *temp1, *temp2 = NULL;

    while(person != NULL){
        if(person->name == name1)
            temp1 = person;
        else if(person->name == name2)
            temp2 = person;
        else
            person = person->next;
    }

    while(temp1->firstFriend != NULL){
        if(temp1->firstFriend->name == temp2->name && temp2->isFriend == true){
            printf("Yes\n");
        }
    }
}