#include <stdio.h>
#include <stdbool.h>
#include <malloc.h>
#include <stdlib.h>

typedef struct Person {
    char fName;
    struct Person *next;
    struct Person *firstFriend;
    bool isFriend;
} Person;

typedef struct List {
    Person *head;
} List;

Person * newPerson(char name, List *l);


int main(void){
    char choice, name1, name2;
    Person *p1;
    List *list;

    printf("Enter choice (P, F, U, L, Q, X): ");
    scanf("%c", &choice);
    while(choice != 'X'){
        switch(choice){
            case 'P':
                printf("Enter first name: ");
                scanf("%s", &name1);
                p1 = newPerson(name1, list);
                printf("Person name: %s\n", p1->fName);
                printf("Enter choice (P, F, U, L, Q, X): ");
                scanf("%c", &choice);

            default:
                printf("Enter choice (P, F, U, L, Q, X): ");
                scanf("%c", &choice);
        }
    }

    return 0;
}

Person * newPerson(char name, List *l){
    Person *p;
    p = (Person*)malloc(sizeof(Person));

    p->fName = name;
    p->next = NULL;
    p->firstFriend = NULL;
    p->isFriend = true;

    return p;
}